# Reading Discum
Structure of Discum: https://docs.google.com/drawings/d/1_PSefOb5nlqEyEAQ14zPfFQuu8hUh9HVJHuV-ymSnTo/edit?usp=sharing
